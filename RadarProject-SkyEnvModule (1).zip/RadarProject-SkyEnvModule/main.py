from simulation import Simulation
import sys

if __name__=="__main__":
    sim = Simulation()
    sim.run()